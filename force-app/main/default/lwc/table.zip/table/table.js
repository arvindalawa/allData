import { LightningElement, track } from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader';
import Table from '@salesforce/resourceUrl/Table';
//Let's configure the columns of the data table
const columns = [ 
    //Key here is cellAttributes object for Particular column
    {label: 'Name', fieldName: 'name', type: 'text',editable:true},
    //Diet type column can accept a css class. The css class name should be passed in field name "dietClass" from server
    {label: 'Overall', fieldName: 'diet', type: 'text',editable:true},
    {label: 'USA', fieldName: 'bloodGroup', type: 'text',editable:true},
    //likewise fvtColor column can also have a css class in fvtColorCSSClass field
    {label: 'India', fieldName: 'fvtColor', type: 'text',editable:true},
    //and working column can have a css class in workingCSSClass field
    // {label: 'Working', fieldName: 'working', type: 'boolean',editable:true}
];
export default class ColorColumnDataTable extends LightningElement {
    @track data = [];
    @track columns = columns;

    async connectedCallback(){
      await loadStyle(this, `${Table}/table.css`);
        const data = [];
        data.push({name : 'Contingency %', diet : '25%', bloodGroup : '20%', 
                   fvtColor : '20%', working : true,});
        data.push({name : 'Base Amt', diet : '', bloodGroup : '', 
                   fvtColor : ''});
        data.push({name : 'COLA Pass Amt ', diet : '',  bloodGroup : '', 
                   fvtColor : ''});
        data.push({name : 'Contingency Amt', diet : '', bloodGroup : '', 
                   fvtColor : '', working : true});
        data.push({name : 'Adjusted Amt', diet : '', bloodGroup : '', 
                   fvtColor : ''});
        data.push({name : 'Disc Amt', diet : '', bloodGroup : '', 
                   fvtColor : '',});
        data.push({name : 'Quoted Amt', diet : '',  bloodGroup : '', 
                   fvtColor : ''});
        data.push({name : 'Total Base Cost', diet : '', bloodGroup : '', 
                   fvtColor : ''});
        data.push({name : 'COLA Cost Adj', diet : '', bloodGroup : '', 
                   fvtColor : ''});
       data.push({name : 'Total Cost', diet : '', bloodGroup : '', 
                   fvtColor : ''})
       data.push({name : 'Margin %', diet : '', bloodGroup : '  ', 
                   fvtColor : ''})
        
        this.data = data;
    }
}